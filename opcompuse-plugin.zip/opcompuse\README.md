# OPCOMPUSE — fast, cheap, memory-optimized Windows computer use

OpenCode plugin (server + TUI parts) that replaces most screenshot/vision-model
computer use with deterministic Windows UI Automation:

- **Screen digest**: element tree (index / role / name / rect / clickable point /
  flags) + built-in WinRT OCR, ~0 model tokens.
- **Watch-ahead cache**: in-process watcher loop keeps the freshest digest on
  disk; `opcompuse_state` reads are **1-5 ms** (idle-adaptive interval).
- **Batched actions**: `opcompuse_act` runs a whole sequence (clicks, keys,
  scrolls, UIA `invoke/select/set/...`) in one spawn and returns the post-action
  state — one call = act + verify.
- **pc-memory**: a plain folder of desktop knowledge ANY model can read.
- **Cheap decider**: `opcompuse_decide` asks a flash-class model using the TEXT
  digest only (no screenshots).
- **TUI panel**: `/opcompuse` opens the right-side session panel showing live
  watcher status, screen-change events, memory stats, and quick toggles.

## Layout

```
opcompuse/
  index.js      server part: tools, hooks, watcher, memory, settings, RPC
  tui.tsx       TUI part: /opcompuse right-side session panel
  rpc.js        typed server<->TUI contract (status, watch, settings, memory)
  ps/opcompuse.lib.ps1    UIA digest + OCR + native input core
  ps/state.ps1            digest entry (-Mode full|quick|find)
  ps/act.ps1              batched executor (SendInput + UIA patterns)
  ps/watch.ps1            optional standalone daemon loop (not needed normally)
  README.md
```

## Data and memory

- Watcher cache files: `%TEMP%\opencode\opcompuse\{alive,state,state}\.json`
- **pc-memory** (durable, model-readable, plain folder):
  `C:\Users\<you>\.local\share\opencode\opcompuse\pc-memory\`
  - `index.md`    auto-generated quick reference — read this first
  - `apps.json`   per app: title + last successful action chains (op chains only)
  - `places.json` file/URL places the user's tasks touched
  - `memory-events.md` rolling screen-change events (+ optional watcher-model notes)
  - `settings.json` runtime settings mirror

**Privacy (hard rule):** pc-memory never stores usernames, passwords, tokens,
API keys, or private login data. Anything matching those words is refused at
save. Typed text from `opcompuse_act` is never memorized — only the op chain
(e.g. `writeline > key ctrl+s`) and safe file paths.

## Speed techniques (the "how")

1. Cache first: `opcompuse_state` → hot digest ~1-5 ms.
2. Batch: one `opcompuse_act` call with waits between steps — a full act+verify
   cycle ≈ 1 s, well under the 2 s per decision budget.
3. Element ops over pixels: `invoke`/`set`/`focus` act on the UI model —
   deterministic, no coordinates, no screenshots.
4. Memory hints: digests append `#MEM` lines from pc-memory so repeat tasks skip
   exploration; `index.md` preloads app/places knowledge before long tasks.
5. Adaptive watcher: full-speed while the screen changes, backs off while idle.
6. OCR budget: OCR throttled (`ocrEveryMs`) and skipped when the element tree
   already answers the question.

## Controls (toggle in seconds)

- Runtime: `opcompuse_settings { action: "get" }` / `{ action: "set", ... }`
- Config (`opencode.jsonc`): plugin options `memory`, `memoryAuto`,
  `memoryConfirm`, `access` (minimal|standard|full), `decider`, `watchModel`
  (`watcherModel`), `interpreterEverySec`, `watchIntervalMs`, `ocrEveryMs`, `psEntry`.
- Panel: `/opcompuse` (TUI right-side panel), keys: `t` watcher toggle,
  `m` memory toggle, `r` refresh, `esc` close.

Access levels:
- `minimal` — element/keyboard ops only (no pixel clicks), safest
- `standard` (default) — everything except destructive combos
- `full` — everything

## Fallback

windows-mcp / the `computer-use` subagent stay available for pixels-only
content (games, video, remote sessions) and `win`-key shortcuts.

## Defaults of note

- decider model: `opencode-go/glm-5.3-flash` (~3.3 s, cheap). Alternatives:
  `opencode/glm-5.3-flash-free` (daily free quota) or a local LM Studio /
  KoboldCpp model for $0.
- watcher model: **empty by default** — the watcher is local-only, so watching
  costs nothing 24/7. Set `watcherModel` to have a weak model interpret events
  into memory notes every `interpreterEverySec` seconds.
